export default class Project {
    constructor(name) {
        this.projectName = name;
        this.taskList = [];
    }
}